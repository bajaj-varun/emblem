package com.pocproject.services;

import com.pocproject.pojos.TennantAppSummary;
import com.pocproject.repositories.TennantAppSummaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TennantAppSummaryService {
    @Autowired
    TennantAppSummaryRepository repo;

    public Iterable<TennantAppSummary> listAll() {
        return repo.findAll();
    }

    public void save(TennantAppSummary tennantAppSummary) {
        repo.save(tennantAppSummary);
    }

    public TennantAppSummary get(long id) {
        return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }
}
