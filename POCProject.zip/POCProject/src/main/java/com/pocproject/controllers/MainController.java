package com.pocproject.controllers;

import com.pocproject.pojos.TennantAppSummary;
import com.pocproject.services.TennantAppSummaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Controller
public class MainController {
    @Autowired
    TennantAppSummaryService tennantAppSummaryService;

    @RequestMapping(value="/",method = RequestMethod.GET)
    public String homepage(){
        return "homePage";
    }

    @RequestMapping("/summary")
    public String viewHomePage(Model model) {
        Iterable<TennantAppSummary> apps = tennantAppSummaryService.listAll();
        model.addAttribute("apps", apps);

        return "tenantSummary";
    }

    @RequestMapping("/new")
    public String showNewProductPage(Model model) {
        TennantAppSummary appSummary = new TennantAppSummary();
        model.addAttribute("appSummary", appSummary);

        return "newAppSummary";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("appSummary") TennantAppSummary summary) {
        tennantAppSummaryService.save(summary);

        return "redirect:/";
    }

    @Bean
    public ViewResolver getViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("templates/");
        //resolver.setSuffix(".html");
        return resolver;
    }
}
