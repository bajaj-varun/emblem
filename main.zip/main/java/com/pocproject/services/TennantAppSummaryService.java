package com.pocproject.services;

import com.pocproject.pojos.TennantAppSummary;
import com.pocproject.repositories.TennantAppSummaryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TennantAppSummaryService {
    Logger logger = LoggerFactory.getLogger(TennantAppSummaryService.class);

    @Autowired
    TennantAppSummaryRepository repo;

    public Iterable<TennantAppSummary> listAll() {
        return repo.findAll();
    }

    public void save(TennantAppSummary tennantAppSummary) {
        logger.info(tennantAppSummary.toString());
        tennantAppSummary.setLastUpdated((""+System.currentTimeMillis()));
        repo.save(tennantAppSummary);
    }

    public TennantAppSummary get(Long id) {
        return repo.findById(id).get();
    }

    public void delete(long id) {
        repo.deleteById(id);
    }
}
