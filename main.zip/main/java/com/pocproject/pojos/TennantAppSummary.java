package com.pocproject.pojos;

import javax.persistence.*;

@Entity(name = "tennant_and_app_summary_tbl")
public class TennantAppSummary {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long  id;

    @Column(name = "Tenant_Name")
    private String tenantName;

    @Column(name = "Tenant_Code")
    private String tenantCode;

    @Column(name = "Senior_Owner")
    private String seniorOwner;

    @Column(name = "Tech_Owner")
    private String techOwner;

    //apps_use_case
    @Column(name = "apps_use_case")
    private String appsOrUseCase;

    @Column(name = "App_code")
    private String appCode;

    //private ProductServices productServices;
    //private DataLake dataLake;

    @Column(name = "DD")
    private boolean DD;
    @Column(name = "DAS")
    private boolean DAS;
    @Column(name = "SH")
    private boolean SH;
    @Column(name = "EAS")
    private boolean EAS;

    @Column(name = "event_streaming")
    private String EventStreaming;

    @Column(name = "Magellan")
    private String Magellan;
    @Column(name = "ET")
    private String ET;
    //private DLM dlm;
    @Column(name = "BDI")
    private boolean BDI;
    @Column(name = "BDA")
    private boolean BDA;

    @Column(name = "Business_Impact")
    private String businessImpact;
    @Column(name = "last_updated")
    private String lastUpdated;
    @Column(name = "Comments")
    private String Comments;

    public boolean isDD() {
        return DD;
    }

    public void setDD(boolean DD) {
        this.DD = DD;
    }

    public boolean isDAS() {
        return DAS;
    }

    public void setDAS(boolean DAS) {
        this.DAS = DAS;
    }

    public boolean isSH() {
        return SH;
    }

    public void setSH(boolean SH) {
        this.SH = SH;
    }

    public boolean isEAS() {
        return EAS;
    }

    public void setEAS(boolean EAS) {
        this.EAS = EAS;
    }

    public String getEventStreaming() {
        return EventStreaming;
    }

    public void setEventStreaming(String eventStreaming) {
        EventStreaming = eventStreaming;
    }

    public String getMagellan() {
        return Magellan;
    }

    public void setMagellan(String magellan) {
        Magellan = magellan;
    }

    public String getET() {
        return ET;
    }

    public void setET(String ET) {
        this.ET = ET;
    }

    public boolean isBDI() {
        return BDI;
    }

    public void setBDI(boolean BDI) {
        this.BDI = BDI;
    }

    public boolean isBDA() {
        return BDA;
    }

    public void setBDA(boolean BDA) {
        this.BDA = BDA;
    }

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public String getTenantCode() {
        return tenantCode;
    }

    public void setTenantCode(String tenantCode) {
        this.tenantCode = tenantCode;
    }

    public String getSeniorOwner() {
        return seniorOwner;
    }

    public void setSeniorOwner(String seniorOwner) {
        this.seniorOwner = seniorOwner;
    }

    public String getTechOwner() {
        return techOwner;
    }

    public void setTechOwner(String techOwner) {
        this.techOwner = techOwner;
    }

    public String getAppsOrUseCase() {
        return appsOrUseCase;
    }

    public void setAppsOrUseCase(String appsOrUseCase) {
        this.appsOrUseCase = appsOrUseCase;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

   /* public ProductServices getProductServices() {
        return productServices;
    }

    public void setProductServices(ProductServices productServices) {
        this.productServices = productServices;
    }*/

    public String getBusinessImpact() {
        return businessImpact;
    }

    public void setBusinessImpact(String businessImpact) {
        this.businessImpact = businessImpact;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getComments() {
        return Comments;
    }

    public void setComments(String comments) {
        Comments = comments;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
