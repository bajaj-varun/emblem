package com.pocproject.pojos;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name = "tennant_and_app_summary_tbl")
public class TennantAppSummary {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long  id;
    private String tenantName;
    private String tenantCode;
    private String seniorOwner;
    private String techOwner;
    private String appsOrUseCase;
    private String appCode;
    private boolean DD;
    private boolean DAS;
    private boolean SH;
    private boolean EAS;
    private String EventStreaming;
    private String Magellan;
    private String ET;
    private boolean BDI;
    private boolean BDA;
    private String businessImpact;
    private String lastUpdated;
    private String Comments;

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
