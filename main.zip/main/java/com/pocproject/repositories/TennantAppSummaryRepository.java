package com.pocproject.repositories;

import com.pocproject.pojos.TennantAppSummary;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TennantAppSummaryRepository extends MongoRepository<TennantAppSummary, Long> {
}
