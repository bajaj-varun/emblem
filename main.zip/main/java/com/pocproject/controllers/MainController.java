package com.pocproject.controllers;

import com.pocproject.pojos.TennantAppSummary;
import com.pocproject.services.TennantAppSummaryService;
import com.pocproject.utils.ExcelGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Controller
public class MainController {
    Logger logger = LoggerFactory.getLogger(MainController.class);

    @Autowired
    TennantAppSummaryService tennantAppSummaryService;

    @RequestMapping(value="/",method = RequestMethod.GET)
    public String homepage(Model model){
        Iterable<TennantAppSummary> apps = tennantAppSummaryService.listAll();
        model.addAttribute("apps", apps);

        return "homePage";
    }

    @RequestMapping(path = {"/edit","/edit/{id}"})
    public String viewHomePage(Model model, @PathVariable("id") Long id){
        logger.info("id =>"+id);
        TennantAppSummary apps = tennantAppSummaryService.get(id);
        model.addAttribute("appSummary", apps);
        return "newAppSummary";
    }

    @RequestMapping("/new")
    public String showNewProductPage(Model model) {
        TennantAppSummary appSummary = new TennantAppSummary();
        model.addAttribute("appSummary", appSummary);

        return "newAppSummary";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("appSummary") TennantAppSummary summary) {
        logger.debug(summary.toString());
        tennantAppSummaryService.save(summary);
        return "redirect:/";
    }

    @GetMapping(value = "/download/AppInventory.xlsx")
    public ResponseEntity<InputStreamResource> excelCustomersReport() throws IOException {
        List<TennantAppSummary> appSummaries = (List<TennantAppSummary>) tennantAppSummaryService.listAll();

        ByteArrayInputStream in = ExcelGenerator.appSummaryToExcel(appSummaries);
        // return IOUtils.toByteArray(in);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=Technical app inventory.xlsx");

        return ResponseEntity
                .ok()
                .headers(headers)
                .body(new InputStreamResource(in));
    }


    @Bean
    public ViewResolver getViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("templates/");
        //resolver.setSuffix(".html");
        return resolver;
    }
}
